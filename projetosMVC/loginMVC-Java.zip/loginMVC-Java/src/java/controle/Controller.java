package controle;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "Controller", urlPatterns = {"/Controller", "/camadas/Controller"})
public class Controller extends HttpServlet {

    /**
     * Processa as solicitacoes (requests) HTTP tanto para o metodo GET qto POST
     * @param request servlet request
     * @param response servlet response
     */
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String acao = request.getParameter("acao");
        // faz a analise da acao do controle 
        if (acao == null || acao.equalsIgnoreCase("login")) {
            request.getRequestDispatcher("/formlogin.jsp?msg=Informe seu Usuario e Senha.").forward(request, response);
        } else if (acao.equalsIgnoreCase("autenticar")) {
            autenticar(request, response);
        } else if (acao.equalsIgnoreCase("cadastrar")) {
            //Aqui faz as validacoes necessarias e requisita o metodo da classe DAO responsavel por cadastrar o usuario.
            ;
        } else if (acao.equalsIgnoreCase("excluir")) {
            //Aqui faz as validacoes necessarias e requisita o metodo da classe DAO responsavel por excluir o usuario.
            ;
        }
    }

    private void autenticar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // recupera os parametros do formulário de Login
        String login = request.getParameter("login");
        String senha = request.getParameter("senha");
        if (login.equalsIgnoreCase("admin") && senha.equalsIgnoreCase("123")) {
            request.getSession().setAttribute("login", login);
            request.getRequestDispatcher("/view/homepage.jsp").forward(request, response);
        } else {
            request.getRequestDispatcher("/formlogin.jsp?msg=Usuario ou Senha Invalida!").forward(request, response);
        }
    }

}
